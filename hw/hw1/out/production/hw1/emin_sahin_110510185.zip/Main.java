public class Main {
    public static void main(String[] args) {
        MathClass mathClass = new MathClass();
        System.out.println(mathClass.isEven(4));
        System.out.println(mathClass.calculateNorm(2, new int[]{3, 4}));
        System.out.println(mathClass.isDistinct(new float[]{3,4,5,6,7,8,9}));
    }
}