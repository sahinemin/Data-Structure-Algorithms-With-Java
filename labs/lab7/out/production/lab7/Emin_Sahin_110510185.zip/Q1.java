public class Q1 {
    public static void main(String[] args) {
        System.out.println(multiplication(4,6));
    }
    static int sum=0;
    public static int multiplication (int m,int n){
        sum +=m;
        n--;
        if(n>0)
            return multiplication(m,n);
        else
            return sum;
    }
}
